# review_packet

Created UTC: 2026-06-05T04:19:26+00:00

## Included
- `dashboard/breakthrough_board.md` (1639 bytes)
- `dashboard/iteration_log.md` (2360 bytes)
- `dashboard/kill_board.md` (5512 bytes)
- `dashboard/leaderboard.csv` (64527 bytes)
- `dashboard/morning_brief.md` (2459 bytes)
- `dashboard/scoop_report.md` (7616 bytes)
- `ideas/NEW_200_triage.md` (19985 bytes)
- `lessons/LESSONS_LEDGER.md` (5291 bytes)
- `queues/gpu_after_mps.yaml` (3067 bytes)
- `queues/gpu_backfill.yaml` (2448 bytes)
- `queues/gpu_foreground.yaml` (426 bytes)
- `queues/mac_continue.yaml` (394 bytes)
- `queues/mps_first.yaml` (7250 bytes)
- `queues/parked.yaml` (1625 bytes)
- `registry/CE13_warmup_policy_selector.yaml` (606 bytes)
- `registry/CE21_no_gap_filter.yaml` (566 bytes)
- `registry/C_A1_cvar_evt_clip_grid.yaml` (796 bytes)
- `registry/C_D1_osc_static_cluster_stress.yaml` (596 bytes)
- `registry/C_E1_paroquant_parity.yaml` (596 bytes)
- `registry/C_F_survival_stable_core.yaml` (999 bytes)
- `registry/L_A1_mmlu_pro_info_ceiling.yaml` (590 bytes)
- `registry/L_A2_verifier_rerank.yaml` (1079 bytes)
- `registry/L_B1_damage_avoidance_trust.yaml` (679 bytes)
- `registry/L_C2_c2c_kv_lcf_anchor.yaml` (1007 bytes)
- `registry/L_Q1_receiver_query_packet.yaml` (1026 bytes)
- `registry/L_SCORECOMP_wz_bins_deployable.yaml` (758 bytes)
- `results/mps_first/L_PC1_cross_family_specialist_ceiling/raw_rows.jsonl` (620 bytes)
- `results/mps_first/L_PC1_cross_family_specialist_ceiling/summary.json` (1177 bytes)
- `results/mps_first/L_PC2_tool_augmented_source_ceiling/raw_rows.jsonl` (1709 bytes)
- `results/mps_first/L_PC2_tool_augmented_source_ceiling/summary.json` (879 bytes)
- `scripts/overnight_v3_corrected_probes.py` (37511 bytes)
- `scripts/run_mps_first_iteration.py` (22320 bytes)

## Skipped / Truncated
- None

## Guardrails
- No paths matching `*_confirm*` are included.
- No model weights, binary arrays, or caches are included.
- Files over 5 MB are skipped or represented by a 200-line head.
