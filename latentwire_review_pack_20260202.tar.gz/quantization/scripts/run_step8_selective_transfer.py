#!/usr/bin/env python3
import argparse
import json
import os
import re
import shutil
import socket
import subprocess
import sys
import time
from pathlib import Path


REQUIRED_MODULES_GPU = [
    "rosetta",
    "torch",
    "transformers",
    "datasets",
    "huggingface_hub",
    "yaml",
    "numpy",
    "tqdm",
]

REQUIRED_MODULES_LOCAL = [
    "rosetta",
    "torch",
    "transformers",
    "datasets",
    "huggingface_hub",
    "yaml",
    "numpy",
    "tqdm",
]
LOCAL_TORCH_VERSION = "2.2.2"


def die(msg):
    print(f"ERROR: {msg}", file=sys.stderr)
    sys.exit(1)


def parse_eval_datasets(raw):
    if not raw:
        return ["openbookqa", "ai2-arc"]
    parts = re.split(r"[,\s]+", raw.strip())
    return [p for p in parts if p]


def dataset_slug(name):
    if name == "ai2-arc":
        return "arc_c"
    return re.sub(r"[^A-Za-z0-9]+", "_", name).strip("_").lower()


def parse_eval_range(raw):
    if raw is None:
        return None
    match = re.match(r"^\s*(\d+)\s*:\s*(\d+)\s*$", raw)
    if not match:
        die("Invalid --eval-range. Expected format start:end (e.g., 0:200).")
    return [int(match.group(1)), int(match.group(2))]


def run_cmd(cmd, cwd=None, env=None, log_file=None):
    cmd_str = " ".join(cmd)
    if log_file:
        log_file.write(f"\n$ {cmd_str}\n")
        log_file.flush()
    print(f"$ {cmd_str}")
    proc = subprocess.Popen(
        cmd,
        cwd=cwd,
        env=env,
        stdout=subprocess.PIPE,
        stderr=subprocess.STDOUT,
        text=True,
        bufsize=1,
    )
    assert proc.stdout is not None
    for line in proc.stdout:
        print(line, end="")
        if log_file:
            log_file.write(line)
    ret = proc.wait()
    if ret != 0:
        die(f"Command failed ({ret}): {cmd_str}")


def check_gpu():
    if shutil.which("nvidia-smi") is None:
        die("nvidia-smi not found. Run this script on a GPU node.")
    res = subprocess.run(["nvidia-smi", "-L"], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
    if res.returncode != 0:
        die("No GPUs detected by nvidia-smi. Run this script on a GPU node.")


def find_conda_exe():
    return os.environ.get("CONDA_EXE") or shutil.which("conda")


def find_conda_env_prefix(conda_exe, env_name):
    try:
        res = subprocess.run(
            [conda_exe, "env", "list", "--json"], capture_output=True, text=True, check=True
        )
        data = json.loads(res.stdout)
        for env_path in data.get("envs", []):
            if Path(env_path).name == env_name:
                return env_path
    except Exception:
        return None
    return None


def ensure_env(env_name, project_root, args):
    current_env = os.environ.get("CONDA_DEFAULT_ENV")
    if current_env == env_name:
        return

    conda_exe = find_conda_exe()
    if conda_exe is None:
        die("conda not found in PATH. Load your conda module and retry.")

    if args.no_reexec:
        die(f"Not running inside conda env '{env_name}'. Activate it and retry.")

    res = subprocess.run([conda_exe, "env", "list"], capture_output=True, text=True)
    if env_name not in res.stdout:
        print(f"Conda env '{env_name}' not found. Creating it now...")
        run_cmd([conda_exe, "create", "-n", env_name, "python=3.10", "-y"])

    script_path = Path(__file__).resolve()
    forwarded = [arg for arg in sys.argv[1:] if arg != "--no-reexec"]
    env_prefix = find_conda_env_prefix(conda_exe, env_name)
    python_exe = None
    if env_prefix:
        python_exe = Path(env_prefix) / "bin" / "python"
        if not python_exe.exists():
            python_exe = None
    python_cmd = str(python_exe) if python_exe else "python"
    cmd = [
        conda_exe, "run", "-n", env_name, python_cmd, str(script_path),
        "--project-root", str(project_root),
    ] + forwarded + ["--no-reexec"]
    print("Re-running inside conda env:", " ".join(cmd))
    subprocess.check_call(cmd)
    sys.exit(0)


def _module_in_repo(module, repo_root: Path) -> bool:
    module_file = getattr(module, "__file__", None)
    if not module_file:
        return False
    try:
        return Path(module_file).resolve().is_relative_to(repo_root.resolve())
    except Exception:
        return str(repo_root.resolve()) in str(Path(module_file).resolve())


def ensure_installed(
    c2c_root,
    log_file=None,
    required_modules=None,
    extras=None,
    no_deps=False,
    extra_pip=None,
):
    required_modules = required_modules or REQUIRED_MODULES_GPU
    try:
        import importlib
        imported = {mod: importlib.import_module(mod) for mod in required_modules}
        rosetta_mod = imported.get("rosetta")
        if rosetta_mod and not _module_in_repo(rosetta_mod, Path(c2c_root)):
            raise RuntimeError(f"rosetta resolved to {rosetta_mod.__file__}, expected under {c2c_root}")
        print("Dependencies already installed; skipping pip install.")
        return
    except Exception as exc:
        if log_file:
            log_file.write(f"Dependency check failed or mismatched: {exc}\n")
        pass

    pip_cmd = [sys.executable, "-m", "pip", "install", "-e", "."]
    if no_deps:
        pip_cmd.append("--no-deps")
    run_cmd(pip_cmd, cwd=c2c_root, log_file=log_file)
    if extras:
        run_cmd(
            [sys.executable, "-m", "pip", "install", "-e", f".[{extras}]"],
            cwd=c2c_root,
            log_file=log_file,
        )
    if extra_pip:
        run_cmd([sys.executable, "-m", "pip", "install"] + list(extra_pip), log_file=log_file)


def collect_model_stats(model_name):
    if not model_name:
        return None, "missing_model_name"
    try:
        from transformers import AutoConfig
        local_only = os.environ.get("TRANSFORMERS_OFFLINE", "").lower() in ("1", "true", "yes")
        cfg = AutoConfig.from_pretrained(model_name, local_files_only=local_only)
        hidden_size = getattr(cfg, "hidden_size", None)
        num_layers = getattr(cfg, "num_hidden_layers", None)
        num_heads = getattr(cfg, "num_attention_heads", None)
        num_kv_heads = getattr(cfg, "num_key_value_heads", None) or num_heads
        if not all([hidden_size, num_layers, num_heads, num_kv_heads]):
            return None, "missing_model_stats"
        head_dim = int(hidden_size) // int(num_heads)
        return {
            "hidden_size": int(hidden_size),
            "num_layers": int(num_layers),
            "num_heads": int(num_heads),
            "num_kv_heads": int(num_kv_heads),
            "head_dim": int(head_dim),
        }, None
    except Exception as exc:
        return None, str(exc)


def get_hf_token():
    return os.environ.get("HF_TOKEN") or os.environ.get("HUGGINGFACE_HUB_TOKEN")


def check_hf_model_access(model_name, require_token=False):
    if not model_name:
        return
    token = get_hf_token()
    if require_token and not token:
        die(
            f"HF token required to access model '{model_name}'. "
            "Set HF_TOKEN or HUGGINGFACE_HUB_TOKEN."
        )
    try:
        from huggingface_hub import HfApi
        from huggingface_hub.errors import HfHubHTTPError
    except Exception as exc:
        die(f"huggingface_hub is required for access checks: {exc}")
    try:
        HfApi().model_info(model_name, token=token)
        print(f"HF access OK: {model_name}")
    except HfHubHTTPError as exc:
        status = getattr(getattr(exc, "response", None), "status_code", None)
        if status in (401, 403, 404):
            if not token:
                die(
                    f"HF access check failed for '{model_name}' (status {status}). "
                    "Token missing or repo gated. Set HF_TOKEN or choose a public model."
                )
            die(
                f"HF access denied for '{model_name}' (status {status}). "
                "Verify token + license acceptance."
            )
        raise


def requires_token_hint(model_name):
    if not model_name:
        return False
    lower = model_name.lower()
    return lower.startswith(("meta-llama/", "google/gemma", "mistralai/"))


def load_layer_schedule(path: Path):
    import yaml

    if not path.exists():
        die(f"Layer schedule file not found: {path}")
    data = yaml.safe_load(path.read_text())
    if isinstance(data, dict) and "layer_schedule" in data:
        return data["layer_schedule"]
    if isinstance(data, dict) and ("default" in data or "overrides" in data):
        return data
    die(f"Invalid layer schedule format in {path}")


def resolve_layer_schedule(args, base_model_name):
    if args.kv_quant_layer_schedule and args.kv_quant_last_fp16:
        die("Specify either --kv-quant-layer-schedule or --kv-quant-last-fp16, not both.")
    if args.kv_quant_layer_schedule:
        return load_layer_schedule(Path(args.kv_quant_layer_schedule).expanduser())
    if args.kv_quant_last_fp16:
        stats, err = collect_model_stats(base_model_name)
        if err or not stats:
            die(f"Unable to resolve model stats for layer schedule: {err}")
        num_layers = stats["num_layers"]
        n = int(args.kv_quant_last_fp16)
        if n <= 0 or n > num_layers:
            die(f"kv-quant-last-fp16 must be between 1 and {num_layers}, got {n}")
        layers = list(range(num_layers - n, num_layers))
        return {
            "default": args.kv_quant_scheme,
            "overrides": [
                {"layers": layers, "scheme": "fp16"},
            ],
        }
    return None


def collect_env_info():
    info = {
        "python_executable": sys.executable,
        "python_version": sys.version,
        "conda_default_env": os.environ.get("CONDA_DEFAULT_ENV"),
        "conda_prefix": os.environ.get("CONDA_PREFIX"),
        "hostname": socket.gethostname(),
        "hf_home": os.environ.get("HF_HOME"),
        "transformers_cache": os.environ.get("TRANSFORMERS_CACHE"),
        "hf_datasets_cache": os.environ.get("HF_DATASETS_CACHE"),
        "hf_hub_cache": os.environ.get("HF_HUB_CACHE") or os.environ.get("HUGGINGFACE_HUB_CACHE"),
        "cuda_visible_devices": os.environ.get("CUDA_VISIBLE_DEVICES"),
        "nvidia_smi_path": shutil.which("nvidia-smi"),
    }

    def add_mod(name):
        try:
            mod = __import__(name)
            info[f"{name}_version"] = getattr(mod, "__version__", None)
            info[f"{name}_path"] = getattr(mod, "__file__", None)
        except Exception as exc:
            info[f"{name}_error"] = str(exc)

    for mod in ["torch", "transformers", "datasets", "huggingface_hub", "yaml", "numpy", "tqdm", "rosetta"]:
        add_mod(mod)

    try:
        import torch
        info["torch_cuda_available"] = torch.cuda.is_available()
        info["torch_cuda_device_count"] = torch.cuda.device_count()
    except Exception as exc:
        info["torch_cuda_error"] = str(exc)

    return info


def estimate_bytes(base_model_stats, kv_cache_proportion=1.0, kv_quant_config=None, kv_transfer_config=None):
    if not base_model_stats:
        return {"error": "missing_base_model_stats"}
    num_layers = base_model_stats.get("num_layers")
    num_kv_heads = base_model_stats.get("num_kv_heads")
    head_dim = base_model_stats.get("head_dim")
    if not all([num_layers, num_kv_heads, head_dim]):
        return {"error": "incomplete_base_model_stats"}

    scheme = (kv_quant_config or {}).get("scheme", "fp16")
    quant_enabled = bool((kv_quant_config or {}).get("enabled", False))
    scheme = scheme.lower() if isinstance(scheme, str) else "fp16"
    if not quant_enabled:
        scheme = "fp16"
    bytes_per_element = {
        "int8": 1.0,
        "int4": 0.5,
        "nf4": 0.5,
        "fp8": 1.0,
        "fp16": 2.0,
        "bf16": 2.0,
    }.get(scheme, 2.0)

    effective_proportion = float(kv_cache_proportion or 1.0)
    token_precision_mode = None
    if kv_transfer_config and kv_transfer_config.get("enabled", False):
        token_precision_mode = (kv_transfer_config.get("token_precision_mode") or "").lower()
        token_prop = kv_transfer_config.get("token_select_proportion")
        if token_prop is not None:
            effective_proportion *= float(token_prop)

    bytes_per_token = 2 * int(num_layers) * int(num_kv_heads) * int(head_dim) * bytes_per_element
    index_bytes_per_token = None
    if kv_transfer_config and kv_transfer_config.get("enabled", False):
        index_bytes = kv_transfer_config.get("index_dtype_bytes")
        if index_bytes:
            index_bytes_per_token = effective_proportion * float(index_bytes)

    estimate = {
        "bytes_per_element": bytes_per_element,
        "bytes_per_token": bytes_per_token,
        "effective_proportion": effective_proportion,
        "index_bytes_per_token": index_bytes_per_token,
        "formula": "bytes_per_token * avg_input_length",
    }
    if token_precision_mode == "rd_greedy":
        estimate["token_precision_budget_bytes"] = kv_transfer_config.get("token_precision_budget_bytes")
        estimate["token_precision_candidates"] = kv_transfer_config.get("token_precision_candidates")
        estimate["token_precision_mode"] = token_precision_mode
    return estimate


def collect_system_info():
    info = {
        "nvidia_smi_path": shutil.which("nvidia-smi"),
    }
    try:
        import torch

        info["torch_cuda_available"] = torch.cuda.is_available()
        info["torch_cuda_device_count"] = torch.cuda.device_count()
        if torch.cuda.is_available():
            info["torch_cuda_device_name"] = torch.cuda.get_device_name(0)
            info["torch_cuda_capability"] = torch.cuda.get_device_capability(0)
    except Exception as exc:
        info["torch_error"] = str(exc)

    if info["nvidia_smi_path"]:
        try:
            out = subprocess.check_output(
                [
                    "nvidia-smi",
                    "--query-gpu=name,driver_version,memory.total,memory.used",
                    "--format=csv,noheader,nounits",
                ],
                text=True,
            ).strip()
            info["nvidia_smi"] = out
        except Exception as exc:
            info["nvidia_smi_error"] = str(exc)
    return info


def ensure_numpy_compat(log_file=None):
    try:
        import numpy as np
        major = int(np.__version__.split(".", 1)[0])
        if major < 2:
            return
    except Exception:
        pass
    run_cmd([sys.executable, "-m", "pip", "install", "numpy<2"], log_file=log_file)
    os.execv(sys.executable, [sys.executable, str(Path(__file__).resolve())] + sys.argv[1:])


def resolve_device_for_mode(mode):
    import torch
    if mode == "local":
        if not torch.backends.mps.is_available():
            die("MPS not available. Local mode expects a Mac with MPS support.")
        return torch.device("mps")
    if not torch.cuda.is_available():
        die("CUDA not available. GPU mode expects a CUDA-capable node.")
    return torch.device("cuda")


def create_segmented_kv_cache_index(instruction_length, response_length, proportion, order_mode, device):
    import torch

    if proportion < 0.0 or proportion > 1.0:
        raise ValueError(f"proportion must be between 0.0 and 1.0, got {proportion}")
    if order_mode not in ["front", "back"]:
        raise ValueError(f"order_mode must be 'front' or 'back', got '{order_mode}'")

    instruction_positive_length = int(instruction_length * proportion)
    instruction_negative_length = instruction_length - instruction_positive_length

    complete_sequence = []
    if order_mode == "front":
        complete_sequence.extend([[1, 0]] * instruction_positive_length)
        complete_sequence.extend([[-1, 0]] * instruction_negative_length)
    else:
        complete_sequence.extend([[-1, 0]] * instruction_negative_length)
        complete_sequence.extend([[1, 0]] * instruction_positive_length)
    complete_sequence.extend([[-1, 0]] * response_length)

    if not complete_sequence:
        return []

    segments = []
    current_segment_start = 0
    current_value = complete_sequence[0]
    for i in range(1, len(complete_sequence)):
        if complete_sequence[i] != current_value:
            segment_length = i - current_segment_start
            segment = torch.tensor(current_value, dtype=torch.long).repeat(segment_length, 1).unsqueeze(0).to(device)
            segments.append(segment)
            current_segment_start = i
            current_value = complete_sequence[i]

    segment_length = len(complete_sequence) - current_segment_start
    segment = torch.tensor(current_value, dtype=torch.long).repeat(segment_length, 1).unsqueeze(0).to(device)
    segments.append(segment)
    return segments


def _choices_from_example(example, question_key):
    question_text = example.get(question_key, "")
    raw_choices = example.get("choices")
    choices_texts = []
    if isinstance(raw_choices, dict):
        choices_texts = list(raw_choices.get("text", []))
    elif isinstance(raw_choices, list):
        for item in raw_choices:
            if isinstance(item, dict):
                choices_texts.append(str(item.get("text", "")))
            else:
                choices_texts.append(str(item))

    choices_str = ""
    for i, text in enumerate(choices_texts):
        choices_str += f"{chr(65+i)}. {text}\n"
    return question_text, choices_texts, choices_str


def build_prompt_from_example(example, dataset_name, use_cot=False, use_template=True):
    from rosetta.utils.evaluate import build_prompt

    if dataset_name == "openbookqa":
        question_text, choices_texts, choices_str = _choices_from_example(example, "question_stem")
    elif dataset_name == "ai2-arc":
        question_text, choices_texts, choices_str = _choices_from_example(example, "question")
    else:
        raise ValueError(f"Unsupported local dataset: {dataset_name}")

    prompt_text = build_prompt(
        dataset=dataset_name,
        locale="",
        question=question_text,
        choices=choices_str,
        use_cot=use_cot,
        use_template=use_template,
    )
    return prompt_text, question_text, choices_texts, choices_str


def parse_answer_from_example(example):
    answer_key = example.get("answerKey")
    if isinstance(answer_key, str) and answer_key in ["A", "B", "C", "D"]:
        return answer_key
    return None


def write_status(run_root, status, extra=None):
    if run_root is None:
        return
    run_root.mkdir(parents=True, exist_ok=True)
    manifest_path = run_root / "manifests" / "run_manifest.json"
    manifest_path.parent.mkdir(parents=True, exist_ok=True)
    data = {}
    if manifest_path.exists():
        try:
            data = json.loads(manifest_path.read_text())
        except Exception:
            data = {}
    data["status"] = status
    if extra:
        data.update(extra)
    manifest_path.write_text(json.dumps(data, indent=2))


def cleanup_failed(run_root, args, reason):
    if run_root is None:
        return
    write_status(run_root, "failed", {"error": reason})
    if args.cleanup_failed and run_root.exists():
        shutil.rmtree(run_root)


def load_local_dataset(dataset_name, allow_dummy=False):
    from datasets import load_dataset

    if dataset_name == "openbookqa":
        try:
            return load_dataset("allenai/openbookqa")["test"]
        except Exception as exc:
            if not allow_dummy:
                raise
            print(f"Warning: falling back to dummy OpenBookQA sample ({exc})")
            return [
                {
                    "question_stem": "What do plants need to grow?",
                    "choices": {"text": ["Sunlight", "Noise", "Coal", "Plastic"]},
                    "answerKey": "A",
                }
            ]
    if dataset_name == "ai2-arc":
        try:
            return load_dataset("allenai/ai2_arc", "ARC-Challenge")["test"]
        except Exception as exc:
            if not allow_dummy:
                raise
            print(f"Warning: falling back to dummy ARC sample ({exc})")
            return [
                {
                    "question": "What force keeps objects on the ground?",
                    "choices": {"text": ["Gravity", "Friction", "Magnetism", "Electricity"]},
                    "answerKey": "A",
                }
            ]
    die(f"Unsupported local dataset: {dataset_name}")


def run_local_smoke_test(project_root, data_root, kv_quant_config, kv_transfer_config, args, run_root):
    if args.prep_only:
        print("Note: --prep-only ignored in local mode.")

    run_root.mkdir(parents=True, exist_ok=True)
    (run_root / "manifests").mkdir(parents=True, exist_ok=True)

    log_path = run_root / "local_smoke.log"
    with log_path.open("a", encoding="utf-8") as log_file:
        ensure_numpy_compat(log_file=log_file)
        env_info = collect_env_info()
        print("Environment info:", json.dumps(env_info, indent=2))
        (run_root / "manifests" / "env_info.json").write_text(json.dumps(env_info, indent=2))
        write_status(
            run_root,
            "running",
            {
                "mode": "local",
                "kv_quant_config": kv_quant_config,
                "kv_transfer_config": kv_transfer_config,
                "receiver_only": bool(args.local_receiver_only),
                "include_response": bool(args.include_response),
                "kv_cache_proportion": args.kv_cache_proportion,
                "kv_cache_order_mode": args.kv_cache_order_mode,
            },
        )

        run_cmd(
            ["git", "submodule", "update", "--init", "--recursive", "quantization/C2C"],
            cwd=str(project_root),
            log_file=log_file,
        )

        c2c_root = project_root / "quantization" / "C2C"
        if not c2c_root.is_dir():
            die(
                f"C2C submodule missing at {c2c_root}. "
                "Run from the LatentWire repo root or pass --project-root."
            )

        ensure_installed(
            str(c2c_root),
            log_file=log_file,
            required_modules=REQUIRED_MODULES_LOCAL,
            extras=None,
            no_deps=True,
            extra_pip=[
                f"torch=={LOCAL_TORCH_VERSION}",
                "transformers==4.52.4",
                "datasets",
                "huggingface_hub",
                "pyyaml",
                "numpy<2",
                "tqdm",
                "tiktoken",
                "sentencepiece",
            ],
        )

        from huggingface_hub import snapshot_download
        from transformers import AutoModelForCausalLM, AutoTokenizer
        import torch

        if not hasattr(torch.nn, "RMSNorm"):
            class RMSNorm(torch.nn.Module):
                def __init__(self, hidden_size, eps=1e-6, dtype=None):
                    super().__init__()
                    self.weight = torch.nn.Parameter(torch.ones(hidden_size, dtype=dtype))
                    self.eps = eps

                def forward(self, x):
                    norm = x.pow(2).mean(-1, keepdim=True).add(self.eps).rsqrt()
                    return x * norm * self.weight

            torch.nn.RMSNorm = RMSNorm

        from rosetta.model.projector import load_projector
        from rosetta.model.wrapper import RosettaModel
        from rosetta.utils.evaluate import set_default_chat_template, extract_answer_from_content

        checkpoint_dir = args.checkpoint_dir
        if not args.local_receiver_only:
            if checkpoint_dir is None:
                ckpt_root = data_root / "step_8_selective_transfer" / "local_smoke_tests" / "checkpoints"
                ckpt_root.mkdir(parents=True, exist_ok=True)
                repo_id = "nics-efc/C2C_Fuser"
                pattern = "qwen3_0.6b+qwen2.5_0.5b_Fuser/*"
                local_dir = ckpt_root / "C2C_Fuser"
                snapshot_path = snapshot_download(
                    repo_id=repo_id,
                    allow_patterns=[pattern],
                    local_dir=str(local_dir),
                    local_dir_use_symlinks=False,
                )
                checkpoint_dir = str(local_dir / "qwen3_0.6b+qwen2.5_0.5b_Fuser" / "final")
                manifest = {
                    "repo_id": repo_id,
                    "allow_patterns": [pattern],
                    "snapshot_path": snapshot_path,
                    "checkpoint_dir": checkpoint_dir,
                }
                (run_root / "manifests" / "checkpoint_manifest.json").write_text(
                    json.dumps(manifest, indent=2)
                )

        device = resolve_device_for_mode(args.mode)
        dtype = torch.float16 if device.type in ("cuda", "mps") else torch.float32
        projector_dtype = torch.float16 if device.type == "mps" else dtype

        tokenizer = AutoTokenizer.from_pretrained(args.base_model)
        set_default_chat_template(tokenizer, args.base_model)
        base_model = AutoModelForCausalLM.from_pretrained(args.base_model, torch_dtype=dtype).eval()
        base_model.to(device)

        teacher_model = None
        if not args.local_receiver_only:
            teacher_model = AutoModelForCausalLM.from_pretrained(args.teacher_model, torch_dtype=dtype).eval()
            teacher_model.to(device)

        rosetta = None
        if not args.local_receiver_only:
            ckpt_path = Path(checkpoint_dir)
            projector_list = []
            for proj_json in sorted(ckpt_path.glob("projector_*.json")):
                if proj_json.name == "projector_config.json":
                    continue
                proj = load_projector(str(proj_json))
                pt_path = proj_json.with_suffix(".pt")
                if pt_path.exists():
                    state_dict = torch.load(pt_path, map_location="cpu")
                    for key, value in state_dict.items():
                        if torch.is_tensor(value):
                            state_dict[key] = value.to(projector_dtype)
                    proj.load_state_dict(state_dict, strict=False)
                proj = proj.to(device=device, dtype=projector_dtype)
                projector_list.append(proj)

            rosetta = RosettaModel(
                model_list=[base_model, teacher_model],
                base_model_idx=0,
                projector_list=projector_list,
                include_response=args.include_response,
                kv_quant_config=kv_quant_config,
                kv_transfer_config=kv_transfer_config,
            ).to(device).eval()

            proj_cfg_path = ckpt_path / "projector_config.json"
            rosetta.load_projector_config(str(proj_cfg_path))

        dataset = load_local_dataset(args.local_dataset, allow_dummy=args.allow_dummy_dataset)
        dataset_size = len(dataset)
        if args.local_num_samples < 1:
            die("local_num_samples must be >= 1")
        if args.local_sample_index < 0 or args.local_sample_index >= dataset_size:
            die(
                f"Sample index {args.local_sample_index} out of range for {args.local_dataset} "
                f"(size={dataset_size})"
            )
        end_index = args.local_sample_index + args.local_num_samples
        if end_index > dataset_size:
            die(
                f"Requested {args.local_num_samples} samples starting at {args.local_sample_index}, "
                f"but dataset size is {dataset_size}"
            )

        sample_indices = list(range(args.local_sample_index, end_index))
        samples_dir = run_root / "samples"
        samples_dir.mkdir(parents=True, exist_ok=True)
        summary_rows = []

        for sample_index in sample_indices:
            example = dataset[int(sample_index)]
            prompt_text, question_text, choices_texts, choices_str = build_prompt_from_example(
                example,
                dataset_name=args.local_dataset,
                use_cot=False,
                use_template=True,
            )

            prompt = [{"role": "user", "content": prompt_text}]
            input_text = tokenizer.apply_chat_template(
                prompt, tokenize=False, add_generation_prompt=True, enable_thinking=False
            )
            inputs = tokenizer(input_text, return_tensors="pt").to(device)
            position_ids = inputs["attention_mask"].long().cumsum(-1) - 1

            full_length = inputs["input_ids"].shape[1]
            instruction_length = full_length - 1
            kv_cache_index = create_segmented_kv_cache_index(
                instruction_length=instruction_length,
                response_length=1,
                proportion=args.kv_cache_proportion,
                order_mode=args.kv_cache_order_mode,
                device=device,
            )

            with torch.no_grad():
                if args.local_receiver_only:
                    outputs = base_model.generate(
                        **inputs,
                        do_sample=False,
                        max_new_tokens=args.max_new_tokens,
                    )
                else:
                    outputs = rosetta.generate(
                        **inputs,
                        position_ids=position_ids,
                        kv_cache_index=kv_cache_index,
                        do_sample=False,
                        max_new_tokens=args.max_new_tokens,
                    )

            output_ids = outputs[0]
            input_len = inputs["input_ids"].shape[1]
            generated_ids = output_ids[input_len:]
            generated_text = tokenizer.decode(generated_ids, skip_special_tokens=True).strip()
            full_text = tokenizer.decode(output_ids, skip_special_tokens=True)

            def strip_think_tags(text_value):
                return text_value.replace("<think>", "").replace("</think>", "").strip()

            extracted_answer = extract_answer_from_content(generated_text)
            expected_answer = parse_answer_from_example(example)
            matches = (
                (extracted_answer == expected_answer)
                if extracted_answer is not None and expected_answer is not None
                else (expected_answer in strip_think_tags(generated_text))
                if expected_answer is not None
                else None
            )

            kv_quant_stats = rosetta.get_kv_quant_stats() if rosetta is not None else None
            kv_quant_applied = (rosetta is not None) and kv_quant_config.get("enabled", False)
            meta = {
                "device": str(device),
                "dtype": str(dtype),
                "base_model": args.base_model,
                "teacher_model": args.teacher_model,
                "checkpoint_dir": checkpoint_dir,
                "include_response": bool(args.include_response),
                "max_new_tokens": args.max_new_tokens,
                "output_dir": str(run_root),
                "input_length": input_len,
                "generated_length": int(generated_ids.shape[0]),
                "prompt_text": prompt_text,
                "question_text": question_text,
                "choices_texts": choices_texts,
                "choices_str": choices_str,
                "generated_text": generated_text,
                "extracted_answer": extracted_answer,
                "expected_answer": expected_answer,
                "matches_expected": matches,
                "dataset": args.local_dataset,
                "sample_index": int(sample_index),
                "receiver_only": bool(args.local_receiver_only),
                "kv_quant_config": kv_quant_config,
                "kv_quant_stats": kv_quant_stats,
                "kv_quant_applied": kv_quant_applied,
                "kv_cache_proportion": args.kv_cache_proportion,
                "kv_cache_order_mode": args.kv_cache_order_mode,
            }

            sample_tag = f"sample_{sample_index:05d}"
            (samples_dir / f"{sample_tag}_output.txt").write_text(generated_text + "\n", encoding="utf-8")
            (samples_dir / f"{sample_tag}_output_full.txt").write_text(full_text + "\n", encoding="utf-8")
            (samples_dir / f"{sample_tag}_metadata.json").write_text(json.dumps(meta, indent=2) + "\n", encoding="utf-8")

            summary_rows.append(
                {
                    "sample_index": int(sample_index),
                    "extracted_answer": extracted_answer,
                    "expected_answer": expected_answer,
                    "matches_expected": matches,
                }
            )

        num_correct = sum(1 for row in summary_rows if row["matches_expected"] is True)
        summary = {
            "dataset": args.local_dataset,
            "sample_indices": sample_indices,
            "num_samples": len(sample_indices),
            "num_correct": num_correct,
            "accuracy": (num_correct / len(sample_indices)) if sample_indices else None,
            "kv_quant_config": kv_quant_config,
            "kv_transfer_config": kv_transfer_config,
            "kv_quant_stats": rosetta.get_kv_quant_stats() if rosetta is not None else None,
            "kv_transfer_stats": rosetta.get_kv_transfer_stats() if rosetta is not None else None,
            "include_response": bool(args.include_response),
            "receiver_only": bool(args.local_receiver_only),
            "kv_cache_proportion": args.kv_cache_proportion,
            "kv_cache_order_mode": args.kv_cache_order_mode,
        }
        (run_root / "summary.json").write_text(json.dumps(summary, indent=2) + "\n", encoding="utf-8")
        (run_root / "samples.jsonl").write_text(
            "".join(json.dumps(row) + "\n" for row in summary_rows),
            encoding="utf-8",
        )

        if len(sample_indices) == 1:
            (run_root / "output.txt").write_text(
                (samples_dir / f"sample_{sample_indices[0]:05d}_output.txt").read_text(),
                encoding="utf-8",
            )
            (run_root / "output_full.txt").write_text(
                (samples_dir / f"sample_{sample_indices[0]:05d}_output_full.txt").read_text(),
                encoding="utf-8",
            )
            (run_root / "metadata.json").write_text(
                (samples_dir / f"sample_{sample_indices[0]:05d}_metadata.json").read_text(),
                encoding="utf-8",
            )

        write_status(run_root, "complete")

    print(f"Local smoke test complete. Output in: {run_root}")
    return run_root


def run_gpu_eval(project_root, data_root, kv_quant_config, kv_transfer_config, args, run_root):
    run_root.mkdir(parents=True, exist_ok=True)
    for sub in ("configs", "logs", "results", "manifests"):
        (run_root / sub).mkdir(parents=True, exist_ok=True)

    log_path = run_root / "logs" / "step8.log"
    with log_path.open("a", encoding="utf-8") as log_file:
        env_info = collect_env_info()
        print("Environment info:", json.dumps(env_info, indent=2))
        (run_root / "manifests" / "env_info.json").write_text(json.dumps(env_info, indent=2))
        system_info = collect_system_info()
        (run_root / "manifests" / "system_info.json").write_text(json.dumps(system_info, indent=2))
        write_status(
            run_root,
            "running",
            {
                "mode": "gpu",
                "kv_quant_config": kv_quant_config,
                "kv_transfer_config": kv_transfer_config,
                "kv_cache_proportion": args.kv_cache_proportion,
                "kv_cache_order_mode": args.kv_cache_order_mode,
            },
        )

        run_cmd(
            ["git", "submodule", "update", "--init", "--recursive", "quantization/C2C"],
            cwd=str(project_root),
            log_file=log_file,
        )

        c2c_root = project_root / "quantization" / "C2C"
        if not c2c_root.is_dir():
            die(
                f"C2C submodule missing at {c2c_root}. "
                "Run from the LatentWire repo root or pass --project-root."
            )

        ensure_installed(
            str(c2c_root),
            log_file=log_file,
            required_modules=REQUIRED_MODULES_GPU,
            extras="training,evaluation",
        )

        from huggingface_hub import snapshot_download
        import yaml

        ckpt_root = Path(
            os.environ.get("C2C_CKPT_ROOT", f"/scratch/m000066/{os.environ.get('USER','user')}/c2c_checkpoints")
        )
        ckpt_root.mkdir(parents=True, exist_ok=True)

        repo_id = "nics-efc/C2C_Fuser"
        pattern = "qwen3_0.6b+qwen2.5_0.5b_Fuser/*"
        snapshot_path = None
        checkpoint_dir_override = args.checkpoint_dir_override
        if checkpoint_dir_override:
            checkpoint_dir = checkpoint_dir_override
            repo_id = "override"
            pattern = "override"
            local_dir = None
        else:
            local_dir = ckpt_root / "C2C_Fuser"
            snapshot_path = snapshot_download(
                repo_id=repo_id,
                allow_patterns=[pattern],
                local_dir=str(local_dir),
                local_dir_use_symlinks=False,
            )
            checkpoint_dir = str(local_dir / "qwen3_0.6b+qwen2.5_0.5b_Fuser" / "final")

        if args.eval_recipe:
            eval_recipe_path = Path(args.eval_recipe)
            if not eval_recipe_path.is_absolute():
                eval_recipe_path = c2c_root / eval_recipe_path
        else:
            eval_recipe_path = c2c_root / "recipe" / "eval_recipe" / "unified_eval.yaml"

        eval_cfg = yaml.safe_load(eval_recipe_path.read_text())
        rosetta_cfg = eval_cfg.get("model", {}).get("rosetta_config", {})
        base_model = args.base_model_override or rosetta_cfg.get("base_model")
        teacher_model = args.teacher_model_override or rosetta_cfg.get("teacher_model")
        if args.do_alignment:
            rosetta_cfg["is_do_alignment"] = True
        if args.alignment_strategy:
            rosetta_cfg["alignment_strategy"] = args.alignment_strategy
        if args.base_model_override:
            rosetta_cfg["base_model"] = base_model
        if args.teacher_model_override:
            rosetta_cfg["teacher_model"] = teacher_model

        require_token = args.require_hf_auth or requires_token_hint(base_model) or requires_token_hint(teacher_model)
        check_hf_model_access(base_model, require_token=require_token)
        check_hf_model_access(teacher_model, require_token=require_token)

        base_model_stats, base_model_stats_error = collect_model_stats(base_model)
        if args.kv_quant_last_fp16:
            schedule = resolve_layer_schedule(args, base_model)
            if schedule:
                kv_quant_config = dict(kv_quant_config)
                kv_quant_config["layer_schedule"] = schedule
                write_status(
                    run_root,
                    "running",
                    {
                        "mode": "gpu",
                        "kv_quant_config": kv_quant_config,
                        "kv_cache_proportion": args.kv_cache_proportion,
                        "kv_cache_order_mode": args.kv_cache_order_mode,
                    },
                )

        def git_rev(path):
            try:
                out = subprocess.check_output(["git", "-C", str(path), "rev-parse", "HEAD"])
                return out.decode().strip()
            except Exception:
                return None

        manifest = {
            "repo_id": repo_id,
            "allow_patterns": [pattern],
            "snapshot_path": snapshot_path,
            "checkpoint_dir": checkpoint_dir,
            "base_model": base_model,
            "teacher_model": teacher_model,
            "is_do_alignment": rosetta_cfg.get("is_do_alignment", False),
            "alignment_strategy": rosetta_cfg.get("alignment_strategy"),
            "base_model_stats": base_model_stats,
            "base_model_stats_error": base_model_stats_error,
            "latentwire_commit": git_rev(project_root),
            "c2c_commit": git_rev(c2c_root),
            "hostname": socket.gethostname(),
            "timestamp": time.strftime("%Y-%m-%d %H:%M:%S"),
            "prep_only": bool(args.prep_only),
            "kv_quant_config": kv_quant_config,
            "kv_transfer_config": kv_transfer_config,
            "kv_cache_proportion": args.kv_cache_proportion,
            "kv_cache_order_mode": args.kv_cache_order_mode,
            "eval_recipe_path": str(eval_recipe_path),
            "bytes_estimate": estimate_bytes(
                base_model_stats,
                kv_cache_proportion=args.kv_cache_proportion,
                kv_quant_config=kv_quant_config,
                kv_transfer_config=kv_transfer_config,
            ),
        }
        manifest_path = run_root / "manifests" / "step_8_manifest.json"
        manifest_path.write_text(json.dumps(manifest, indent=2))
        print("Wrote manifest:", manifest_path)

        def patch(cfg_path, dataset, out_dir):
            cfg = yaml.safe_load(Path(cfg_path).read_text())
            cfg.setdefault("eval", {})
            cfg["model"]["rosetta_config"]["checkpoints_dir"] = manifest["checkpoint_dir"]
            cfg["model"]["rosetta_config"]["kv_quant_config"] = kv_quant_config
            cfg["model"]["rosetta_config"]["kv_transfer_config"] = kv_transfer_config
            if args.base_model_override:
                cfg["model"]["rosetta_config"]["base_model"] = base_model
            if args.teacher_model_override:
                cfg["model"]["rosetta_config"]["teacher_model"] = teacher_model
            if args.do_alignment:
                cfg["model"]["rosetta_config"]["is_do_alignment"] = True
            if args.alignment_strategy:
                cfg["model"]["rosetta_config"]["alignment_strategy"] = args.alignment_strategy
            cfg["output"]["output_dir"] = str(out_dir)
            cfg["eval"]["dataset"] = dataset
            cfg["eval"]["kv_cache_proportion"] = args.kv_cache_proportion
            cfg["eval"]["kv_cache_order_mode"] = args.kv_cache_order_mode
            if args.eval_use_cot:
                cfg["eval"]["use_cot"] = True
            if args.eval_no_template:
                cfg["eval"]["use_template"] = False
            if args.eval_limit is not None:
                cfg["eval"]["limit"] = int(args.eval_limit)
            elif args.eval_range is not None:
                cfg["eval"]["limit"] = args.eval_range
            Path(cfg_path).write_text(yaml.safe_dump(cfg, sort_keys=False))

        dataset_cfgs = {}
        for dataset in args.eval_datasets:
            slug = dataset_slug(dataset)
            cfg_path = run_root / "configs" / f"{slug}.yaml"
            cfg_path.write_text(eval_recipe_path.read_text())
            out_dir = run_root / "results" / slug
            patch(cfg_path, dataset, out_dir)
            dataset_cfgs[slug] = cfg_path

        if args.prep_only:
            write_status(run_root, "prep_only")
            print(f"Prep-only complete. Run on GPU to execute evals. Run folder: {run_root}")
            return run_root

        if not args.skip_gpu_check:
            check_gpu()

        timings = {"datasets": {}, "start_time": time.time()}

        def run_eval_with_timing(label, cfg_path):
            start = time.time()
            run_cmd(
                [sys.executable, "script/evaluation/unified_evaluator.py", "--config", str(cfg_path)],
                cwd=str(c2c_root),
                env=os.environ.copy(),
                log_file=log_file,
            )
            timings["datasets"][label] = {"seconds": time.time() - start}
            (run_root / "manifests" / "timings.json").write_text(json.dumps(timings, indent=2))

        for dataset in args.eval_datasets:
            slug = dataset_slug(dataset)
            run_eval_with_timing(slug, dataset_cfgs[slug])

        timings["total_seconds"] = time.time() - timings["start_time"]
        (run_root / "manifests" / "timings.json").write_text(json.dumps(timings, indent=2))

        write_status(run_root, "complete")

    print(f"Step 8 selective transfer complete. Results in: {run_root}")
    return run_root


def main():
    parser = argparse.ArgumentParser(description="Run Step 8 selective KV transfer evals (GPU default, local smoke supported).")
    parser.add_argument(
        "--project-root",
        default=os.getcwd(),
        help="Path to LatentWire repo root (default: current working directory)",
    )
    parser.add_argument(
        "--mode",
        choices=["gpu", "local"],
        default="gpu",
        help="gpu for full evals (default), local for Mac smoke test",
    )
    parser.add_argument("--env", default="rosetta", help="Conda env name to use")
    parser.add_argument("--max-new-tokens", type=int, default=64, help="Local mode generation length")
    parser.add_argument("--base-model", default="Qwen/Qwen3-0.6B", help="Local mode base model")
    parser.add_argument("--teacher-model", default="Qwen/Qwen2.5-0.5B-Instruct", help="Local mode teacher model")
    parser.add_argument(
        "--base-model-override",
        default=None,
        help="GPU mode: override base model in eval recipe",
    )
    parser.add_argument(
        "--teacher-model-override",
        default=None,
        help="GPU mode: override teacher model in eval recipe",
    )
    parser.add_argument(
        "--eval-recipe",
        default=None,
        help="GPU mode: path to eval recipe YAML (default: recipe/eval_recipe/unified_eval.yaml)",
    )
    parser.add_argument(
        "--do-alignment",
        action="store_true",
        help="GPU mode: set is_do_alignment=true in rosetta_config",
    )
    parser.add_argument(
        "--alignment-strategy",
        default=None,
        help="GPU mode: override alignment_strategy in rosetta_config",
    )
    parser.add_argument(
        "--require-hf-auth",
        action="store_true",
        help="Require HF token and validate access to base/teacher models",
    )
    parser.add_argument("--checkpoint-dir", default=None, help="Local mode projector checkpoint dir")
    parser.add_argument(
        "--checkpoint-dir-override",
        default=None,
        help="GPU mode: override projector checkpoint dir (skip HF download)",
    )
    parser.add_argument("--run-tag", default=None, help="Override run tag")
    parser.add_argument("--output-dir", default=None, help="Local mode output dir override")
    parser.add_argument("--hf-cache", default=None, help="Optional HF cache root")
    parser.add_argument("--kv-quant-scheme", choices=["int8", "int4"], default="int8", help="KV quant scheme")
    parser.add_argument("--kv-quant-axis", choices=["head", "layer"], default="head", help="KV quant axis")
    parser.add_argument("--kv-quant-eps", type=float, default=1e-6, help="KV quant epsilon")
    parser.add_argument("--kv-quant-collect-stats", action="store_true", help="Collect quant scale stats")
    parser.add_argument("--disable-kv-quant", action="store_true", help="Disable KV quantization for baseline compare")
    parser.add_argument(
        "--kv-quant-layer-schedule",
        default=None,
        help="Path to JSON/YAML layer schedule (default/overrides).",
    )
    parser.add_argument(
        "--kv-quant-last-fp16",
        type=int,
        default=0,
        help="Promote the last N layers to fp16 (mixed precision).",
    )
    parser.add_argument(
        "--kv-cache-proportion",
        type=float,
        default=1.0,
        help="Proportion of instruction tokens kept for KV cache sharing (0.0-1.0)",
    )
    parser.add_argument(
        "--kv-cache-order-mode",
        choices=["front", "back"],
        default="front",
        help="Which part of instruction tokens to keep when pruning (front/back)",
    )
    parser.add_argument(
        "--disable-kv-transfer",
        action="store_true",
        help="Disable token-level KV transfer (for baselines)",
    )
    parser.add_argument(
        "--kv-select-mode",
        choices=["vnorm_topk", "knorm_topk", "proj_vnorm_topk", "delta_proj_vnorm_topk", "random", "front", "back"],
        default="vnorm_topk",
        help="Token selection mode for sparse transfer (proj_vnorm_topk scores in receiver space)",
    )
    parser.add_argument(
        "--kv-select-proportion",
        type=float,
        default=1.0,
        help="Fraction of tokens to transfer/fuse (0.0-1.0)",
    )
    parser.add_argument(
        "--kv-select-scope",
        choices=["prompt", "instruction_only", "all_context"],
        default="prompt",
        help="Token selection scope",
    )
    parser.add_argument(
        "--kv-select-min-tokens",
        type=int,
        default=64,
        help="Minimum number of tokens to keep during selection",
    )
    parser.add_argument(
        "--token-precision-mode",
        choices=["rd_greedy", "none"],
        default=None,
        help="Token precision allocator mode (rd_greedy for M10).",
    )
    parser.add_argument(
        "--token-precision-candidates",
        default="drop,int4,int8",
        help="Comma-separated precision candidates for RD allocator (e.g., drop,int4,int8).",
    )
    parser.add_argument(
        "--token-precision-budget-bytes",
        type=float,
        default=None,
        help="Per-layer token precision budget in bytes (RD allocator).",
    )
    parser.add_argument(
        "--token-precision-budget-bits-per-elem",
        type=float,
        default=None,
        help="Optional derived bits/elem budget (logged for reference).",
    )
    parser.add_argument(
        "--token-precision-calib-n",
        type=int,
        default=64,
        help="Calibration samples for RD allocator (logged for reference).",
    )
    parser.add_argument(
        "--token-precision-scope",
        choices=["prompt", "instruction_only", "all_context"],
        default=None,
        help="Scope for token-precision allocation (defaults to kv_select_scope).",
    )
    parser.add_argument(
        "--kv-sparse-fuse",
        dest="kv_sparse_fuse",
        action="store_true",
        help="Fuse only selected tokens and scatter back (default)",
    )
    parser.add_argument(
        "--no-kv-sparse-fuse",
        dest="kv_sparse_fuse",
        action="store_false",
        help="Compute full fuser outputs with masked source (debug)",
    )
    parser.set_defaults(kv_sparse_fuse=True)
    parser.add_argument(
        "--kv-scatter-fill",
        choices=["receiver_only", "zeros"],
        default="receiver_only",
        help="How to fill non-selected positions after sparse fusion",
    )
    parser.add_argument(
        "--kv-index-dtype-bytes",
        type=int,
        default=2,
        help="Bytes per token index for effective-bytes accounting",
    )
    parser.add_argument(
        "--kv-include-scale-overhead",
        action="store_true",
        help="Include quantization scale overhead in effective bytes",
    )
    parser.add_argument(
        "--kv-timing-sync",
        action="store_true",
        help="Synchronize CUDA for KV transfer timing (slower but more accurate).",
    )
    parser.add_argument(
        "--eval-datasets",
        default="openbookqa,ai2-arc",
        help="Comma/space-separated eval datasets (default: openbookqa,ai2-arc).",
    )
    parser.add_argument(
        "--eval-use-cot",
        action="store_true",
        help="Enable chain-of-thought prompting in eval config.",
    )
    parser.add_argument(
        "--eval-no-template",
        action="store_true",
        help="Disable chat template in eval config (use raw prompts).",
    )
    parser.add_argument(
        "--eval-limit",
        type=int,
        default=None,
        help="Limit evaluation to first N samples (per dataset).",
    )
    parser.add_argument(
        "--eval-range",
        default=None,
        help="Evaluate a specific index range start:end (per dataset).",
    )
    parser.add_argument(
        "--local-dataset",
        choices=["openbookqa", "ai2-arc"],
        default="openbookqa",
        help="Local smoke dataset (1 sample)",
    )
    parser.add_argument("--local-sample-index", type=int, default=0, help="Local dataset sample index")
    parser.add_argument("--local-num-samples", type=int, default=1, help="Number of local samples to run")
    parser.add_argument(
        "--local-receiver-only",
        action="store_true",
        help="Local-only baseline: run the receiver model without C2C projectors",
    )
    parser.add_argument(
        "--allow-dummy-dataset",
        action="store_true",
        help="Allow a tiny built-in dataset if HF download fails (local only)",
    )
    parser.add_argument("--include-response", action="store_true", help="Enable include_response for RosettaModel")
    parser.add_argument("--skip-gpu-check", action="store_true", help="Skip GPU detection")
    parser.add_argument("--prep-only", action="store_true", help="Run setup + downloads only; skip evaluation")
    parser.add_argument("--cleanup-failed", action="store_true", help="Delete failed run folders")
    parser.add_argument("--no-reexec", action="store_true", help="Internal flag to avoid re-exec loops")
    args = parser.parse_args()

    project_root = Path(args.project_root).resolve()
    if not project_root.is_dir():
        die(f"PROJECT_ROOT not found: {project_root}")
    quant_root = project_root / "quantization"
    if not quant_root.is_dir():
        die(f"quantization/ folder not found under {project_root}")
    data_root = quant_root / "data"

    if args.kv_cache_proportion < 0.0 or args.kv_cache_proportion > 1.0:
        die("kv_cache_proportion must be between 0.0 and 1.0")

    if args.eval_limit is not None and args.eval_limit <= 0:
        die("--eval-limit must be positive")
    if args.eval_limit is not None and args.eval_range is not None:
        die("Use only one of --eval-limit or --eval-range.")
    args.eval_range = parse_eval_range(args.eval_range)
    args.eval_datasets = parse_eval_datasets(args.eval_datasets)

    if args.mode == "gpu" and not args.skip_gpu_check and not args.prep_only:
        check_gpu()

    ensure_env(args.env, project_root, args)

    if args.hf_cache:
        os.environ["HF_HOME"] = args.hf_cache
        os.environ["TRANSFORMERS_CACHE"] = os.path.join(args.hf_cache, "transformers")
    elif args.mode == "local":
        local_cache = data_root / "step_8_selective_transfer" / "local_smoke_tests" / "hf_cache"
        os.environ.setdefault("HF_HOME", str(local_cache))
        os.environ.setdefault("TRANSFORMERS_CACHE", str(local_cache / "transformers"))
    else:
        os.environ.setdefault("HF_HOME", f"/scratch/m000066/{os.environ.get('USER','user')}/.cache/huggingface")
        os.environ.setdefault("TRANSFORMERS_CACHE", os.path.join(os.environ["HF_HOME"], "transformers"))
    os.environ.setdefault("WANDB_DISABLED", "true")

    kv_quant_enabled = not args.disable_kv_quant
    layer_schedule = resolve_layer_schedule(args, args.base_model)

    kv_quant_config = {
        "enabled": kv_quant_enabled,
        "scheme": args.kv_quant_scheme,
        "axis": args.kv_quant_axis,
        "eps": args.kv_quant_eps,
        "collect_stats": bool(args.kv_quant_collect_stats) and kv_quant_enabled,
    }
    if layer_schedule and kv_quant_enabled:
        kv_quant_config["layer_schedule"] = layer_schedule

    if args.kv_select_proportion < 0.0 or args.kv_select_proportion > 1.0:
        die("kv_select_proportion must be between 0.0 and 1.0")
    if args.kv_select_min_tokens < 1:
        die("kv_select_min_tokens must be >= 1")

    token_precision_mode = None
    if args.token_precision_mode and args.token_precision_mode.lower() != "none":
        token_precision_mode = args.token_precision_mode.lower()
    token_precision_candidates = [
        item.strip().lower()
        for item in (args.token_precision_candidates or "").split(",")
        if item.strip()
    ]

    kv_transfer_enabled = not args.disable_kv_transfer
    kv_transfer_config = {
        "enabled": kv_transfer_enabled,
        "token_select_mode": args.kv_select_mode,
        "token_select_proportion": float(args.kv_select_proportion),
        "token_select_scope": args.kv_select_scope,
        "token_select_min_tokens": int(args.kv_select_min_tokens),
        "sparse_fuse": bool(args.kv_sparse_fuse),
        "scatter_fill": args.kv_scatter_fill,
        "index_dtype_bytes": int(args.kv_index_dtype_bytes),
        "include_scale_overhead": bool(args.kv_include_scale_overhead),
        "timing_sync": bool(args.kv_timing_sync),
    }
    if token_precision_mode:
        kv_transfer_config["token_precision_mode"] = token_precision_mode
        if token_precision_candidates:
            kv_transfer_config["token_precision_candidates"] = token_precision_candidates
        if args.token_precision_budget_bytes is not None:
            kv_transfer_config["token_precision_budget_bytes"] = float(args.token_precision_budget_bytes)
        if args.token_precision_budget_bits_per_elem is not None:
            kv_transfer_config["token_precision_budget_bits_per_elem"] = float(args.token_precision_budget_bits_per_elem)
        kv_transfer_config["token_precision_calib_n"] = int(args.token_precision_calib_n)
        kv_transfer_config["token_precision_scope"] = args.token_precision_scope or args.kv_select_scope

    run_root = None
    try:
        if args.mode == "local":
            if args.run_tag is None:
                args.run_tag = time.strftime("local_smoke_%Y%m%d_%H%M%S")
            if args.output_dir:
                run_root = Path(args.output_dir).expanduser().resolve()
            else:
                run_root = data_root / "step_8_selective_transfer" / "local_smoke_tests" / args.run_tag
            run_root = run_local_smoke_test(project_root, data_root, kv_quant_config, kv_transfer_config, args, run_root)
        else:
            if args.run_tag is None:
                args.run_tag = f"{args.kv_quant_scheme}_{time.strftime('%Y%m%d_%H%M%S')}"
            run_root = data_root / "step_8_selective_transfer" / args.run_tag
            run_root = run_gpu_eval(project_root, data_root, kv_quant_config, kv_transfer_config, args, run_root)
    except SystemExit as exc:
        cleanup_failed(run_root, args, f"exit_code={exc.code}")
        raise
    except Exception as exc:
        cleanup_failed(run_root, args, str(exc))
        raise


if __name__ == "__main__":
    main()
